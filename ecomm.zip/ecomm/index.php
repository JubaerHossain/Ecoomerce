
<?php include 'inc/header.php';?>
<?php include 'inc/slider.php';?>


 <div class="main">
  <div class="content">

           <div class="content_top">
    		<div class="heading">
    		<h3>Deshi Fruits</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
	      <div class="section group">

	        <?php
	             $getfpd=$pd->getFrPr();

	              if($getfpd) {                     
                     while($result=$getfpd->fetch_assoc()){
                     		

	        ?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details.php?prid=<?php echo $result['pId'];?>"><img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
					 <h2><?php echo $result['pName']; ?></h2>
					 <p><?php echo $fm->textShorten($result['body'],35); ?></p>
					 <p><span class="price">$<?php echo $result['price']; ?></span></p>
				     <div class="button"><span><a href="details.php?prid=<?php echo $result['pId'];?>" class="details">Details</a></span></div>
				</div>

				<?php } } ?>
				
				
				

			</div>
             

			<div class="content_bottom">
    		<div class="heading">
    		<h3>Bideshi Fruits</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
	      <div class="section group">

	        <?php
	             $getffpd=$pd->getFFrPr();

	              if($getffpd) {                     
                     while($result=$getffpd->fetch_assoc()){
                     		

	        ?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details.php?prid=<?php echo $result['pId'];?>"><img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
					 <h2><?php echo $result['pName']; ?></h2>
					 <p><?php echo $fm->textShorten($result['body'],35); ?></p>
					 <p><span class="price">$<?php echo $result['price']; ?></span></p>
				     <div class="button"><span><a href="details.php?prid=<?php echo $result['pId'];?>" class="details">Details</a></span></div>
				</div>

				<?php } } ?>
				
				
				

			</div>

			
			<div class="content_bottom">
    		<div class="heading">
    		<h3>New Fruits</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
			<div class="section group">


			 <?php
	             $getNpd=$pd->getNPr();

	              if($getNpd) {                     
                     while($result=$getNpd->fetch_assoc()){
                     		

	        ?>
				<div class="grid_1_of_4 images_1_of_4">
					  <a href="details.php?prid=<?php echo $result['pId'];?>"><img src="admin/<?php echo $result['image']; ?>" alt="" /></a>
					 <h2><?php echo $result['pName']; ?></h2>
					<p><span class="price">$<?php echo $result['price']; ?></span></p>
				    <div class="button"><span><a href="details.php?prid=<?php echo $result['pId'];?>" class="details">Details</a></span>

				   </div>

				</div>

				 <?php } } ?>
			</div>
			
    </div>

 </div>

 <?php include 'inc/footer.php';?>




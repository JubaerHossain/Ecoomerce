<?php

if (!isset($_GET['pdfpath']) || $_GET['pdfpath'] == NULL ) {
    echo "
        <script>
            window.location = 'index.php';
        </script>
    ";
}else{



	$path = $_GET['pdfpath'];
	$path = explode('.', $path);
    $path = $path[0].'.pdf';
    $file = $path;

	header('Content-Description: File Transfer');
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename="'.basename($file).'"');
	header('Expires: 0');
	header('Cache-Control: must-revalidate');
	header('Pragma: public');
	header('Content-Length: ' . filesize($file));
	readfile($file);

}


?>
<?php include 'inc/header.php';

if (!isset($_GET['pdfpath']) || $_GET['pdfpath'] == NULL ) {
    echo "
        <script>
            window.location = 'index.php';
        </script>
    ";
}else{

    $path = $_GET['pdfpath'];
}

?>

<a href="down.php?pdfpath=<?php echo $path; ?>">Download</a>

<!-- <embed src="<?php echo $path; ?>" width="100%" height="500px" type='application/pdf'> -->
<iframe src="<?php echo $path; ?>" style="width:100%; height:500px;" frameborder="0"></iframe>
<!-- <object width="100%" height="500px" type="application/html" data="<?php echo $path; ?>"> -->
<?php include 'inc/footer.php'; ?>

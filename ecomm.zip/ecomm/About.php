<?php
/**
* 
*/
class About{
	
	function __construct(argument)
	{
		# code...
	}
}
??
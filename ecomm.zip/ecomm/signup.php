<?php include 'inc/headerall.php'; 

if (Session::get("customerlogin") == true) {
	header("Location:orderdetails.php");
}

if ( $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login']) ) {
    $loginCustomer = $cmr->customerLogin($_POST);
}

if ( $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit']) ) {
    $addCustomer = $cmr->customerAdd($_POST);
}

?>
 <div class="main">
    <div class="content">
    	 
    	<div class="register_account">
    		<h3>Register New Account</h3>
    		<?php  
    			if (isset($addCustomer)) {
    				echo $addCustomer;
    			}
    		?>
    		<form action="" method="post" >
		   		<table>
		   			<tbody>
						<tr>
							<td>
								<div>
								<input type="text" placeholder="username" name="username" >
								</div>
								
								<div>
								   <input type="text" placeholder="City" name="city" >
								</div>
								
								<div>
									<input type="text" placeholder="Zip-Code" name="zip" >
								</div>
								<div>
									<input type="text" placeholder="E-Mail" name="email" >
								</div>
			    			</td>
			    			<td>
								<div>
									<input type="text" placeholder="Address" name="address" >
								</div>
					    		<div>
									<select id="country" name="country" class="frm-field required">

										<option value="null">Select a Country</option>         
										<option value="AF">Afghanistan</option>
										<option value="AL">Albania</option>
										<option value="DZ">Algeria</option>
										<option value="AR">Argentina</option>
										<option value="AM">Armenia</option>
										<option value="AW">Aruba</option>
										<option value="AU">Australia</option>
										<option value="AT">Austria</option>
										<option value="AZ">Azerbaijan</option>
										<option value="BS">Bahamas</option>
										<option value="BH">Bahrain</option>
										<option value="BD">Bangladesh</option>

					         		</select>
							    </div>		        
			
					            <div>
					          		<input type="text" placeholder="Phone" name="phone" >
					            </div>
								  
								<div>
									<input type="text" placeholder="Password" name="password" >
								</div>

			    			</td>
		    			</tr> 
		    		</tbody>
		    	</table> 
		   		<div class="search"><div><button name="submit" class="grey">Create Account</button></div></div>
		    	<p class="terms">By clicking 'Create Account' you agree to the <a href="#">Terms &amp; Conditions</a>.</p>
		    	<div class="clear"></div>
		    </form>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
<?php include 'inc/footer.php'; ?>
<?php 
       $filepath=realpath(dirname(__FILE__));
       include_once ($filepath.'/../Database/Session.php');   
       Session::checkLogin();     
       include_once ($filepath.'/../Helpers/Format.php');
       include_once ($filepath.'/../Database/Database.php');  
?>
<?php 
/**
* 
*/
class AdminLogin{
	private $db;
	private $fm;
	
	function __construct()
	{
		$this->db=new Database();
		$this->fm=new Format();
	}

	public function AdminLogin( $alName, $alPass){

       $alName=$this->fm->validation($alName);
       $alPass=$this->fm->validation($alPass);

       $alName= mysqli_real_escape_string($this->db->link,$alName);
       $alPass= mysqli_real_escape_string($this->db->link,$alPass);
       if (empty($alName) || empty($alPass)) {
       	$logsms="fill up ";
       	return $logsms;
       }else{
       	$query="SELECT * FROM adminlog WHERE alName='$alName' AND alPass='$alPass'";
       	$result=$this->db->select($query);
       	if ($result !=false) {
       		$value=$result->fetch_assoc();
       		Session::set("adminlogin",true);
       		Session::set("alName",$value['alName']);
       		Session::set("alEmail",$value['alEmail']);
       		Session::set("alPass",$value['alPass']);
       		header("location:dashboard.php");
       	}else{
       		$logsms="Name and pass not match";
       		
       		return $logsms;
       	}
       }
	}


/* second admin */

      public function prInser($post){

       $adminName=$this->fm->validation($post['adminName']);
        $adminName= mysqli_real_escape_string($this->db->link, $post['adminName']);
        $email=$this->fm->validation($post['email']);
        $email= mysqli_real_escape_string($this->db->link, $post['email']);
        $phone =$this->fm->validation($post['phone']);
        $phone = mysqli_real_escape_string($this->db->link, $post['phone']);
        $password =$this->fm->validation($post['password']);
        $password = mysqli_real_escape_string($this->db->link, $post['password']);

        
    //validation 

    if ($adminName == "" || $email=="" || $phone=="" || $password=="") {

        $csms="<span class='error'>Fields must not be empty </span>";
            return $csms;
    }
     
        $query="INSERT INTO adminadd(adminName,email,phone,password) VALUES('$adminName','$email','$phone','$password')";

        $prinsert=$this->db->insert($query);

            if ($prinsert) {
                  $csms = "<span class='success'>Admin Insert successfully</span>";
                  return $csms;
            }else{
                  $csms = "<span class='error'>Admin not Insert </span>";
                  return $csms;

            }

    

     }

     public function delPrById($id){ 
       

       $query="DELETE  FROM adminadd WHERE adminID ='$id'";
      $deldata=$this->db->delete($query);     

       if($deldata) {
            $csms = "<span class='success'>Product  Deleted successfully</span>";
                  return $csms;
              }else{

                  $csms = "<span class='error'>Product  not Deleted </span>";
                  return $csms;

              }
  }


     public function getallpr(){

      $query="SELECT * FROM adminadd ORDER BY adminID ASC";
      $result=$this->db->select($query);
      return $result;


  }


  /* admin edit*/

  public function prUpdate($post,$file, $id){

    
        $adminName= mysqli_real_escape_string($this->db->link, $post['adminName']);
        
        $email= mysqli_real_escape_string($this->db->link, $post['email']);
       
        $phone = mysqli_real_escape_string($this->db->link, $post['phone']);
        
        $password = mysqli_real_escape_string($this->db->link, $post['password']);
        

    //validation 

     if ($adminName == "" || $email=="" || $phone=="" || $password=="") {

        $csms="<span class='error'>Fields must not be empty </span>";
            return $csms;
    }

        
        $query="UPDATE adminadd 
                         SET 
                          adminName='$adminName',
                          email='$email',
                          phone='$phone',
                          password='$password'

                          WHERE adminID='$id'";


                             $updated_row=$this->db->update($query);

            if ($updated_row) {
                  $csms = "<span class='success'>Admin update successfully</span>";
                  return $csms;
            }else{
                  $csms = "<span class='error'>Admin not update </span>";
                  return $csms;

            }

         
       

     }

     public function getPrById($id){
    $query="SELECT * FROM adminadd WHERE adminID ='$id'";
      $result=$this->db->select($query);
      return $result;


  }


  

     public function getAdmin(){

      $query="SELECT p.*, c.alName
       FROM adminadd as p,adminlog as c
       WHERE p.adminName=c.alName

       ORDER BY p.adminID DESC";
      $result=$this->db->select($query);
      return $result;


  }

}
?>
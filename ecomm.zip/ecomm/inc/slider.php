

	<div class="header_bottom">
	           <div class="header_bottom_left">
			<div class="section group">
						<div class="Blue_panel_with_menu clearfix">

<div class="panel_blue_container">
<ul class="left_navigation clearfix">
<li><a href="#" class="active" title="Css Menu">Category</a></li>
                 
                 <li><a href="deshi.php">Desi Fruits</a></li>
                <li><a href="ca1.php">Bedeshi Fruits</a></li>
                <li><a href="deshi.php">Fresh Fruits</a></li>
                <li><a href="deshi.php">Fruits Juice</a></li>
                <li><a href="ca1.php">Fruits Food</a></li>            


</ul>
</div>
<div class="bl"></div>
<div class="br"></div>
</div>
					
				
			</div>
			
		  <div class="clear"></div>
		</div>
		
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
             
			<section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<li><img src="images/1.jpg" alt=""/></li>
						<li><img src="images/2.jpg" alt=""/></li>
						<li><img src="images/1.jpg" alt=""/></li>
						<li><img src="images/2.jpg" alt=""/></li>
				    </ul>
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
  </div>
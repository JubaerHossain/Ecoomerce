<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include'../classes/AdminLogin.php';?>
<?php include_once'../Helpers/Format.php';?>
<?php
   $prfm=new Format();
  $prl=new AdminLogin();
 if (isset($_GET['delpr'])) {
 	$id=$_GET['delpr'];
 	$id = preg_replace('/[^A-Za-z0-9_-]+/', '-', $_GET['delpr']);
 	$delPr=$prl->delPrById($id);
 }
 ?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Post List</h2>
        <div class="block">

                <?php

                 if (isset($delPr)) {
                 	echo $delPr;
                 }
                ?>   
            <table class="data display datatable" id="example">
			<thead>
				<tr>
					<th>Admin No</th>
					<th>Admin Name</th>
					<th>E-mail</th>
					<th>Phone</th>
					<th>Passwaord</th>
					
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
			<?php
                     $getpr=$prl->getallpr();
                     if ($getpr) {
                     	$i=0;
                     	while($result=$getpr->fetch_assoc()){
                     		$i++;
                     
					?>
				<tr class="odd gradeX">
					<td><?php echo $i; ?></td>
					<td><?php echo $result['adminName']; ?></td>
					<td><?php echo $result['email']; ?></td>
					<td><?php echo $result['phone']; ?></td>
					<td><?php echo $result['password']; ?></td>

					<td><a href="adminedit.php?ptid=<?php echo $result['adminID']; ?>">Edit</a> || <a onclick="return confirm('are you want to delete!')" href="?delpr=<?php echo $result['adminID']; ?>">Delete</a></td>
				</tr>
				<?php } } ?>
				
			</tbody>
		</table>

       </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
		setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>

 <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>Deshi Fruits &amp; All rights Reseverd </p>
    </div>
</body>
</html>

<?php include 'inc/header.php'; 
include'../classes/AdminLogin.php';

if ( $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit']) ) {
    $addCustomer = $pd->customerAdd($_POST);
}


?>
 <div class="main">
    <div class="content">
    	 
    	<div class="register_account">
    		<h3 style="margin-left: 221px;font-size: 29px;border: 2px;margin-bottom: 20px;">Register New Account</h3>
    		<?php  
    			if (isset($addCustomer)) {
    				echo $addCustomer;
    			}
    		?>
    		<form action="" method="post" >
		   		<table style="border-collapse: collapse;border-spacing: 0;">
		   			<tbody>
						<tr>
							<td>
								<div>
								<input type="text" placeholder="username" name="username" >
								</div>
								
								<div>
								   <input type="text" placeholder="City" name="city" >
								</div>
								
								
								<div>
									<input type="text" placeholder="E-Mail" name="email" >
								</div>
			    			</td>
			    			<td>
								<div>
									<input type="text" placeholder="Address" name="address" >
								</div>
					    				        
			
					            <div>
					          		<input type="text" placeholder="Phone" name="phone" >
					            </div>
								  
								<div>
									<input type="text" placeholder="Password" name="password" >
								</div>

			    			</td>
		    			</tr> 
		    		</tbody>
		    	</table> 
		   		<div class="search"><div><button name="submit" class="grey">Create New Admin</button></div></div>
		    	<div class="clear"></div>
		    </form>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
<?php include 'inc/footer.php'; ?>
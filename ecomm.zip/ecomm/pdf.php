<?php include 'inc/headerall.php';

if ( $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit']) ) {
    $pdfInsert = $ct->pdfInsert($_FILES);
}

?>
<ul>
    <?php
        $result = $ct->getPdfAll();
        if ($result) {
            while ($value = $result->fetch_assoc()) {    
    ?> 
	<li><a href="showpdf.php?pdfpath=<?php echo $value['path']; ?>"><?php echo $value['path']; ?></a></li>     
    <?php
        }
    }
    ?>
</ul>


<form action="" method="post" enctype="multipart/form-data" >
	<table class="form" >        
	    <tr>
	        <td>
	            <input type="file" name="pdf" />
	        </td>
	        <td>
	            <input type="submit" name="submit" Value="Save" />
	        </td>
	    </tr>
    </table>  
</form>
<?php include 'inc/footer.php'; ?>